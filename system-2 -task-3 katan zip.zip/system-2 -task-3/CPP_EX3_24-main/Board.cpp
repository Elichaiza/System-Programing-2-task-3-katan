//elichaiza@gmail.com
//ID:318691821

#include "Board.hpp"
#include <iostream>
#include <stdexcept>
#include <utility>
#include <set>
#include <vector>
#include "Tile.hpp"
#include "Vertex.hpp"
#include "Edge.hpp"
#include <string>
using namespace std;

Board::Board() {
    vector<Vertex*> node;    //create a vector of the nodes to poot them inside the ways
    for (size_t i = 0; i < 54; i++){
        Vertex *v = new Vertex(i);
        node.push_back(v);
    }

// all the nodes that we crete will be get inside the ways(edge)

    Edge *edge0 = new Edge(node[0], node[1]);
    Edge *edge1 = new Edge(node[1], node[2]);
    Edge *edge2 = new Edge(node[2], node[3]);
    Edge *edge3 = new Edge(node[3], node[4]);
    Edge *edge4 = new Edge(node[4], node[5]);
    Edge *edge5 = new Edge(node[5], node[0]);
    Edge *edge6 = new Edge(node[2], node[6]);
    Edge *edge7 = new Edge(node[6], node[7]);
    Edge *edge8 = new Edge(node[7], node[8]);
    Edge *edge9 = new Edge(node[8], node[9]);
    Edge *edge10 = new Edge(node[9], node[3]);
    Edge *edge11 = new Edge(node[7], node[10]);
    Edge *edge12 = new Edge(node[10], node[11]);
    Edge *edge13 = new Edge(node[11], node[12]);
    Edge *edge14 = new Edge(node[12], node[13]);
    Edge *edge15 = new Edge(node[13], node[8]);
    Edge *edge16 = new Edge(node[12], node[14]);
    Edge *edge17 = new Edge(node[14], node[15]);
    Edge *edge18 = new Edge(node[15], node[16]);
    Edge *edge19 = new Edge(node[16], node[17]);
    Edge *edge20 = new Edge(node[17], node[13]);
    Edge *edge21 = new Edge(node[17], node[18]);
    Edge *edge22 = new Edge(node[18], node[19]);
    Edge *edge23 = new Edge(node[19], node[9]);
    Edge *edge24 = new Edge(node[19], node[20]);
    Edge *edge25 = new Edge(node[20], node[21]);
    Edge *edge26 = new Edge(node[21], node[4]);
    Edge *edge27 = new Edge(node[21], node[22]);
    Edge *edge28 = new Edge(node[22], node[23]);
    Edge *edge29 = new Edge(node[23], node[28]);
    Edge *edge30 = new Edge(node[28], node[5]);
    Edge *edge31 = new Edge(node[23], node[27]);
    Edge *edge32 = new Edge(node[22], node[24]);
    Edge *edge33 = new Edge(node[24], node[25]);
    Edge *edge34 = new Edge(node[25], node[26]);
    Edge *edge35 = new Edge(node[26], node[27]);
    Edge *edge36 = new Edge(node[20], node[29]);
    Edge *edge37 = new Edge(node[29], node[30]);
    Edge *edge38 = new Edge(node[30], node[24]);
    Edge *edge39 = new Edge(node[18], node[31]);
    Edge *edge40 = new Edge(node[31], node[32]);
    Edge *edge41 = new Edge(node[32], node[29]);
    Edge *edge42 = new Edge(node[16], node[33]);
    Edge *edge43 = new Edge(node[33], node[34]);
    Edge *edge44 = new Edge(node[34], node[31]);
    Edge *edge45 = new Edge(node[15], node[35]);
    Edge *edge46 = new Edge(node[35], node[36]);
    Edge *edge47 = new Edge(node[36], node[37]);
    Edge *edge48 = new Edge(node[37], node[33]);
    Edge *edge49 = new Edge(node[37], node[38]);
    Edge *edge50 = new Edge(node[38], node[39]);
    Edge *edge51 = new Edge(node[39], node[40]);
    Edge *edge52 = new Edge(node[40], node[34]);
    Edge *edge53 = new Edge(node[40], node[41]);
    Edge *edge54 = new Edge(node[41], node[42]);
    Edge *edge55 = new Edge(node[42], node[32]);
    Edge *edge56 = new Edge(node[42], node[43]);
    Edge *edge57 = new Edge(node[43], node[44]);
    Edge *edge58 = new Edge(node[44], node[30]);
    Edge *edge59 = new Edge(node[44], node[45]);
    Edge *edge60 = new Edge(node[45], node[46]);
    Edge *edge61 = new Edge(node[46], node[25]);
    Edge *edge62 = new Edge(node[43], node[47]);
    Edge *edge63 = new Edge(node[47], node[48]);
    Edge *edge64 = new Edge(node[48], node[49]);
    Edge *edge65 = new Edge(node[49], node[45]);
    Edge *edge66 = new Edge(node[41], node[50]);
    Edge *edge67 = new Edge(node[50], node[51]);
    Edge *edge68 = new Edge(node[51], node[47]);
    Edge *edge69 = new Edge(node[39], node[52]);
    Edge *edge70 = new Edge(node[52], node[53]);
    Edge *edge71 = new Edge(node[53], node[50]);

    vector<Vertex*> nodes;  //this will be the nodes of the game
    vector<Edge*> wayes;    // this weill be the ways
    int number=0;        // this will be the number on the Tile




 // create tile 1
    node.push_back(node[0]);
    node.push_back(node[1]);
    for (size_t i = 2; i <= 5; i++)
    {
        node.push_back(node[i]); //geting inside the vector of the vertexes six specific node.
    }
    wayes.push_back(edge0); // geting inside the vector of the Edge six specific Edges.
    wayes.push_back(edge1);
    wayes.push_back(edge2);
    wayes.push_back(edge3);
    wayes.push_back(edge4);
    wayes.push_back(edge5);

    number = 10;                  // the number that will be in the Tile
    Tile* a1=new Tile(node, wayes, number, string ("Mountian"));
    this->tiles.emplace_back(a1); // create new tile on board with the members of this tile (include vertor of edges from the vector of node)
    node.clear(); // clean the node and the wayes to the next Tile
    wayes.clear();

    // create tile 2
    node.push_back(node[2]);
    for (size_t i = 6; i <= 9; i++)
    {
        node.push_back(node[i]);
    }
    node.push_back(node[3]);
    wayes.push_back(edge6);
    wayes.push_back(edge7);
    wayes.push_back(edge8);
    wayes.push_back(edge9);
    wayes.push_back(edge10);
    wayes.push_back(edge2);
    number = 2;

    Tile* a2=new Tile(node, wayes, number, string ("Pasture"));
    this->tiles.emplace_back(a2);
    node.clear();
    wayes.clear();

    // create tile 3
    node.push_back(node[7]);
    for (size_t i = 10; i <= 12; i++)
    {
        node.push_back(node[i]);
    }
    node.push_back(node[13]);
    node.push_back(node[8]);
    wayes.push_back(edge11);
    wayes.push_back(edge12);
    wayes.push_back(edge13);
    wayes.push_back(edge14);
    wayes.push_back(edge15);
    wayes.push_back(edge8);
    number = 9;

   
    Tile* a3=new Tile(node, wayes, number, string ("Forest"));
    this->tiles.emplace_back(a3);
    node.clear();
    wayes.clear();

    // create tile 4
    node.push_back(node[13]);
    node.push_back(node[12]);
    for (size_t i = 14; i <= 17; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge14);
    wayes.push_back(edge16);
    wayes.push_back(edge17);
    wayes.push_back(edge18);
    wayes.push_back(edge19);
    wayes.push_back(edge20);
    number = 10;

    Tile* a4=new Tile(node, wayes, number, string ("Hill"));
    this->tiles.emplace_back(a4);
    node.clear();
    wayes.clear();

    // create tile 5
    node.push_back(node[9]);
    node.push_back(node[8]);
    node.push_back(node[13]);
    for (size_t i = 17; i <= 19; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge9);
    wayes.push_back(edge15);
    wayes.push_back(edge20);
    wayes.push_back(edge21);
    wayes.push_back(edge22);
    wayes.push_back(edge23);
    number = 4;

    Tile* a5=new Tile(node, wayes, number, string ("Pasture"));
    this->tiles.emplace_back(a5);
    node.clear();
    wayes.clear();

    // create tile 6
    node.push_back(node[4]);
    node.push_back(node[3]);
    node.push_back(node[9]);
    node.push_back(node[19]);
    node.push_back(node[20]);
    node.push_back(node[21]);

    wayes.push_back(edge3);
    wayes.push_back(edge10);
    wayes.push_back(edge23);
    wayes.push_back(edge24);
    wayes.push_back(edge25);
    wayes.push_back(edge26);
    number = 6;

    Tile* a6=new Tile(node, wayes, number, string ("Hill"));
    this->tiles.emplace_back(a6);
    node.clear();
    wayes.clear();

    // create tile 7
    node.push_back(node[28]);
    node.push_back(node[5]);
    node.push_back(node[4]);
    for (size_t i = 21; i <= 23; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge30);
    wayes.push_back(edge4);
    wayes.push_back(edge26);
    wayes.push_back(edge27);
    wayes.push_back(edge28);
    wayes.push_back(edge29);
    number = 12;

    Tile* a7=new Tile(node, wayes, number, string ("Field"));
    this->tiles.emplace_back(a7);
    node.clear();
    wayes.clear();

    // create tile 8
    node.push_back(node[23]);
    node.push_back(node[22]);
    for (size_t i = 24; i <= 27; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge31);
    wayes.push_back(edge28);
    wayes.push_back(edge32);
    wayes.push_back(edge33);
    wayes.push_back(edge34);
    wayes.push_back(edge35);
    number = 9;

    Tile* a8=new Tile(node, wayes, number, string ("Field"));
    this->tiles.emplace_back(a8);
    node.clear();
    wayes.clear();

    // create tile 9
    node.push_back(node[22]);
    node.push_back(node[21]);
    node.push_back(node[20]);
    node.push_back(node[29]);
    node.push_back(node[30]);
    node.push_back(node[24]);

    wayes.push_back(edge27);
    wayes.push_back(edge25);
    wayes.push_back(edge36);
    wayes.push_back(edge37);
    wayes.push_back(edge38);
    wayes.push_back(edge32);
    number = 11;


    Tile* a9=new Tile(node, wayes, number, string ("Forest"));
    this->tiles.emplace_back(a9);
    node.clear();
    wayes.clear();

    // create tile 10
    node.push_back(node[20]);
    node.push_back(node[19]);
    node.push_back(node[18]);
    node.push_back(node[31]);
    node.push_back(node[32]);
    node.push_back(node[29]);

    wayes.push_back(edge24);
    wayes.push_back(edge22);
    wayes.push_back(edge39);
    wayes.push_back(edge40);
    wayes.push_back(edge41);
    wayes.push_back(edge36);

    Tile* a10=new Tile(node, wayes, number, string ("Desert"));
    this->tiles.emplace_back((a10));
    node.clear();
    wayes.clear();

    // create tile 11
    node.push_back(node[18]);
    node.push_back(node[17]);
    node.push_back(node[16]);
    node.push_back(node[33]);
    node.push_back(node[34]);
    node.push_back(node[31]);

    wayes.push_back(edge21);
    wayes.push_back(edge19);
    wayes.push_back(edge42);
    wayes.push_back(edge43);
    wayes.push_back(edge44);
    wayes.push_back(edge39);
    number = 3;

    Tile* a11=new Tile(node, wayes, number, string ("Forest"));
    this->tiles.emplace_back(a11);
    node.clear();
    wayes.clear();

    // create tile 12
    node.push_back(node[16]);
    node.push_back(node[15]);
    node.push_back(node[35]);
    node.push_back(node[36]);
    node.push_back(node[37]);
    node.push_back(node[33]);

    wayes.push_back(edge18);
    wayes.push_back(edge45);
    wayes.push_back(edge46);
    wayes.push_back(edge47);
    wayes.push_back(edge48);
    wayes.push_back(edge42);
    number = 8;

    Tile* a12=new Tile(node, wayes, number, string ("Mountain"));
    this->tiles.emplace_back(a12);
    node.clear();
    wayes.clear();

    // create tile 13
    node.push_back(node[34]);
    node.push_back(node[33]);
    for (size_t i = 37; i <= 40; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge43);
    wayes.push_back(edge48);
    wayes.push_back(edge49);
    wayes.push_back(edge50);
    wayes.push_back(edge51);
    wayes.push_back(edge52);
    number = 5;

    Tile* a13=new Tile(node, wayes, number, string ("Pasture"));
    this->tiles.emplace_back(a13);
    node.clear();
    wayes.clear();

    // create tile 14
    node.push_back(node[32]);
    node.push_back(node[31]);
    node.push_back(node[34]);
    for (size_t i = 40; i <= 42; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge40);
    wayes.push_back(edge44);
    wayes.push_back(edge52);
    wayes.push_back(edge53);
    wayes.push_back(edge54);
    wayes.push_back(edge55);
    number = 4;

    Tile* a14=new Tile(node, wayes, number, string ("Field"));
    this->tiles.emplace_back(a14);
    node.clear();
    wayes.clear();

    // create tile 15
    node.push_back(node[30]);
    node.push_back(node[29]);
    node.push_back(node[32]);
    for (size_t i = 42; i <= 44; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge37);
    wayes.push_back(edge41);
    wayes.push_back(edge55);
    wayes.push_back(edge56);
    wayes.push_back(edge57);
    wayes.push_back(edge58);
    number = 3;

    Tile* a15=new Tile(node, wayes, number, string ("Mountain"));
    this->tiles.emplace_back(a15);
    node.clear();
    wayes.clear();

    // create tile 16
    node.push_back(node[25]);
    node.push_back(node[24]);
    node.push_back(node[30]);
    for (size_t i = 44; i <= 46; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge33);
    wayes.push_back(edge38);
    wayes.push_back(edge58);
    wayes.push_back(edge59);
    wayes.push_back(edge60);
    wayes.push_back(edge61);
    number = 8;

    Tile* a16=new Tile(node, wayes, number, string ("Forest"));
    this->tiles.emplace_back(a16);
    node.clear();
    wayes.clear();

    // create tile 17
    node.push_back(node[45]);
    node.push_back(node[44]);
    node.push_back(node[43]);
    for (size_t i = 47; i <= 49; i++)
    {
        node.push_back(node[i]);
    }
    wayes.push_back(edge59);
    wayes.push_back(edge57);
    wayes.push_back(edge62);
    wayes.push_back(edge63);
    wayes.push_back(edge64);
    wayes.push_back(edge65);
    number = 5;

    Tile* a17=new Tile(node, wayes, number, string ("Hill"));
    this->tiles.emplace_back(a17);
    node.clear();
    wayes.clear();

    // create tile 18
    node.push_back(node[43]);
    node.push_back(node[42]);
    node.push_back(node[41]);
    node.push_back(node[50]);
    node.push_back(node[51]);
    node.push_back(node[47]);

    wayes.push_back(edge56);
    wayes.push_back(edge54);
    wayes.push_back(edge66);
    wayes.push_back(edge67);
    wayes.push_back(edge68);
    wayes.push_back(edge62);
    number = 6;

    Tile* a18=new Tile(node, wayes, number, string ("Field"));
    this->tiles.emplace_back(a18);
    node.clear();
    wayes.clear();

    // create tile 19
    node.push_back(node[41]);
    node.push_back(node[40]);
    node.push_back(node[39]);
    node.push_back(node[52]);
    node.push_back(node[53]);
    node.push_back(node[50]);

    wayes.push_back(edge53);
    wayes.push_back(edge51);
    wayes.push_back(edge69);
    wayes.push_back(edge70);
    wayes.push_back(edge71);
    wayes.push_back(edge66);
    number = 11;

    Tile* a19=new Tile(node, wayes, number, string ("Pasture"));
    this->tiles.emplace_back(a19);
    node.clear();
    wayes.clear();
}

void Board::clearBoard() {

   //to deleate all the board we nead to dealte firest the nodes and the ways after that the tile.
    delete (tiles[0]->getVertexes()[0]);
    delete (tiles[0]->getVertexes()[1]);
    delete (tiles[0]->getVertexes()[2]);
    delete (tiles[0]->getVertexes()[3]);
    delete (tiles[0]->getVertexes()[4]);
    delete (tiles[0]->getEdges()[5]);
    // delete tiles 2,3
    for (size_t i = 1; i < 3; i++){
        for (size_t j = 1; j < 5; j++){
            delete (tiles[i]->getVertexes()[j]);
            delete (tiles[i]->getEdges()[j - 1]);
        }
        delete (tiles[i]->getEdges()[4]);
    }
    // delete tile 4,5,6,7,8
    delete (tiles[3]->getVertexes()[2]);
    delete (tiles[3]->getEdges()[1]);
    delete (tiles[3]->getEdges()[2]);
    delete (tiles[4]->getEdges()[2]);
    delete (tiles[5]->getEdges()[2]);
    delete (tiles[6]->getEdges()[2]);
    delete (tiles[6]->getVertexes()[0]);
    delete (tiles[6]->getEdges()[0]);
    delete (tiles[6]->getEdges()[5]);
    delete (tiles[7]->getVertexes()[0]);
    delete (tiles[7]->getEdges()[0]);
    delete (tiles[7]->getVertexes()[1]);
    delete (tiles[7]->getEdges()[1]);
    delete (tiles[7]->getVertexes()[2]);
    delete (tiles[7]->getEdges()[2]);
    delete (tiles[7]->getVertexes()[3]);
    delete (tiles[7]->getEdges()[3]);
    delete (tiles[7]->getVertexes()[4]);
    delete (tiles[7]->getEdges()[4]);
    delete (tiles[7]->getVertexes()[5]);
    delete (tiles[7]->getEdges()[5]);

    // delete tiles 9,10,11,12
    for (size_t i = 8; i < 12; i++){
        for (size_t j = 1; j < 5; j++){
            delete (tiles[i]->getVertexes()[j]);
            delete (tiles[i]->getEdges()[j - 1]);
        }
        delete (tiles[i]->getEdges()[4]);
    }

    // delete tiles 13,14,15,16
    delete (tiles[12]->getVertexes()[3]);
    delete (tiles[12]->getEdges()[2]);
    delete (tiles[12]->getEdges()[3]);
    delete (tiles[12]->getEdges()[5]);
    delete (tiles[13]->getEdges()[5]);
    delete (tiles[14]->getEdges()[5]);
    delete (tiles[15]->getEdges()[5]);
    delete (tiles[15]->getVertexes()[5]);
    delete (tiles[15]->getEdges()[4]);
    // delete tiles 17,18,19
    delete (tiles[16]->getVertexes()[0]);
    delete (tiles[16]->getVertexes()[5]);
    delete (tiles[16]->getEdges()[5]);
    for (size_t i = 16; i < 19; i++)
    {
        for (size_t j = 1; j < 5; j++)
        {
            delete (tiles[i]->getVertexes()[j]);
            delete (tiles[i]->getEdges()[j - 1]);
        }
        delete (tiles[i]->getEdges()[4]);
    }
    for(size_t i=0;i<17;i++){
        tiles[i]->getVertexes().clear();
        tiles[i]->getEdges().clear();
    }
    tiles.clear();
}

vector<Tile*> Board::getBoard() {
    cout<<"the tiles of the game is:";
    return this->tiles;

}

void Board::printBoard() {
    for (size_t i=0;i<this->tiles.size();i++) {
        cout<<"this is the tile "<< i <<":"<<endl;
        for(size_t i=0;i<this->tiles[i]->getVertexes().size();i++) {
            cout<<"the vertexes:" << this->tiles[i]->getVertexes()[i] << endl;
        }
        for(size_t i=0;i<this->tiles[i]->getEdges().size();i++) {
            cout<<"{the edges:"<< this->tiles[i]->getEdges()[i]<<endl;
        }
        cout<<""<<endl;
    }
}

/**
 * The function return the node if exists else, print messagge and return nullptr
 */
Vertex *Board::find_node(int index){
    Vertex *kodkod = NULL;
//we will be sherch of all over the tiles if exsist this node
    for (size_t p=0;p<19;p++){
        for (size_t j = 0; j < 6; j++) {
            //check if this is the index
            if (tiles[p]->getVertexes()[j]->GetIndex() == index){
                kodkod = tiles[p]->getVertexes()[j];
                return  kodkod;
            }
        }
    }
    return  kodkod;
}

/**
 *The function return the way if exists else, print messagge and return nullptr
 */

Edge* Board::find_way(int nodeOne, int noedTwo){
    if (this->find_node(nodeOne) == NULL || this->find_node(noedTwo) == NULL)
        __throw_invalid_argument("wrong index: No exist node with that index in the board");
    Edge *addressOfEdge = nullptr;
    // go over all tiles in board, and in all tile check the six edges.
    for (size_t i = 0; i < this->tiles.size(); i++){
        for (size_t j = 0; j < 6; j++){
            if (this->tiles[i]->getEdges()[j]->Equal(nodeOne, noedTwo)){
             // check if find the required vertex in board
                addressOfEdge = this->tiles[i]->getEdges()[j];
                return addressOfEdge;
            }
        }
    }
    return addressOfEdge;
}

/**
 * The function get circleNumber and return the tiles that have this number(for the most its be 2)
 */
vector<Tile*> Board::findSameNumberOnTiles(int rollNumber){
    vector<Tile*> result_tiles;
    for (size_t i = 0; i < this->tiles.size(); i++){
        if (tiles[i]->getCircleNumber() == rollNumber)
            result_tiles.push_back(tiles[i]);
    }
    return result_tiles;
}
vector<Edge *> Board::edgesIntersection(Vertex *v){
    vector<Edge *> intersection;
    for (size_t i = 0; i < this->tiles.size(); i++){
        Tile* t = tiles[i];
        for (size_t j = 0; j < 6; j++){
            Edge *e = t->getEdges()[j];
            if (e->getNomOfVertexOne() == v->GetIndex() || e->getNumOfVertexTwo() == v->GetIndex()){
                if (intersection.size() == 0)
                    intersection.push_back(e);
                if (intersection.size() == 1 && intersection[0] != e)
                    intersection.push_back(e);
                if (intersection.size() == 2 && intersection[0] != e && intersection[1] != e)
                    intersection.push_back(e);
                if (intersection.size() == 3)
                    return intersection;
            }
        }
    }
    return intersection;
}

/**
 * The function get vertex and return vector of the tiles that intersect in this vertex
 */
vector<Tile*> Board::tilesIntersection(Vertex *v){
    vector<Tile*> intersection;
    for (size_t i = 0; i < this->tiles.size(); i++){
        Tile *t = tiles[i];
        for (size_t j = 0; j < 6; j++)
        {
            if (t->getVertexes()[j]->GetIndex() == v->GetIndex())
            {
                intersection.push_back(t);
                break;
            }
        }
    }
    return intersection;
}








