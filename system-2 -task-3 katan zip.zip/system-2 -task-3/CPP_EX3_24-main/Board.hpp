//elichaiza@gmail.com
//ID:318691821
#ifndef BOARD_H
#define BOARD_H

#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>

#include "Edge.hpp"
#include "Tile.hpp"
using namespace std;

class Board {
private:
    vector<Tile*> tiles;

public:
    Board();
    void printBoard();
    void clearBoard(); // destructor
    vector<Tile*> getBoard();
    Vertex *find_node(int index);
    Edge *find_way(int index1, int index2);
    vector<Tile*> findSameNumberOnTiles( int rollNumber);
    vector<Edge*> edgesIntersection(Vertex *v);      // get vertex and return all edge that meet in this vertex
    vector<Tile*> tilesIntersection(Vertex *v);       // get vertex and retun all tile that meet in this vertex
};



#endif //BOARD_H
