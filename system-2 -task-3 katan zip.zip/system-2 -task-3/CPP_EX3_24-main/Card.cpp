//elichaiza@gmail.com
//ID:318691821

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <limits>
#include "DevelopmentCard.hpp"
#include "Card.hpp"
#include "Edge.hpp"
#include "Player.hpp"

using namespace std;

Card::Card(string TypeOfCard) {
    this-> TypeOfCard=TypeOfCard;
}

string Card::getDevelopmentType(){
    return "getTypeCard";
}

string Card::getTypeCard() {
    return this->TypeOfCard;
}

/**
 *Here we manipulate the game, we will take the player the card that will be dealt to him
 *and the board and according to that we will play
 */
void Card::regularCard(vector<Player*>& p, size_t i, Board& b){
    cout << p[i]->getName() << " reach the development card " <<  this->getDevelopmentType() << " " << this->getTypeCard() << endl;
    if(this->TypeOfCard == "building")
        UsingTwoRoadCard(p[i], b);
    if(this->TypeOfCard == "plenty")
        UsingplentyYearCard(p[i]);
    if(this->TypeOfCard == "monopoly")
        UsingmonopolyCard(p, i);
}

/**
when the player get a road card development
he  will be get a two road and we will be check if the roads are empty
if is empty the road will be to the player else the player need to send us another road
 */
void Card::UsingTwoRoadCard(Player* p, Board& b){
    cout << "Please enter two nodes for the first way you want to build on it road:" << endl;
    int node1, node2;
    cin >> node1;
    cin >> node2;
    //check if the road are exsist
    Edge* way1 = b.find_way(node1, node2);

    while (p->can_build_a_vileage(way1, b) == false){ //continue scan until the road is valid
        cout << "It's invalid lane. Please enter new junctions" << endl;
        cin >> node1;
        cin >> node2;
        way1 = b.find_way(node1, node2);
    }
    p->buldingRoad(node1, node2, b); //build new road

    //check the second way
    cout << "Please enter two nodes for the second way you want to build on it road:" << endl;
    cin >> node1;
    cin >> node2;
    Edge* lane2 = b.find_way(node1, node2);
    //if the way arent empty/:
    while (p->can_build_a_vileage(lane2, b) == false){
        cout << "It's invalid way. Please enter a two new nodes:" << endl;
        cin >> node1;
        cin >> node2;
        lane2 = b.find_way(node1, node2);
    }
    p->buldingRoad(node1, node2, b);

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //clean buffer
}

/**
 * when a player win in a card plentyYear we get player and add him 2 resources according his choice
 */
void Card::UsingplentyYearCard(Player* p){
    string resource1;
    string resource2;
    p->printResources();
    cout << "Please enter two resources you want to get from stack: (brick, Wood, iron, wheat, wool) " << endl;
    cin >> resource1;
    cin >> resource2;

    int res1 = p->getCardFromString(resource1);
    int res2 = p->getCardFromString(resource2);

    p->setResources(res1, p->getResourcesPlayer()[(size_t)res1] + 1);
    p->setResources(res2, p->getResourcesPlayer()[(size_t)res2] + 1);

    if(res1!=res2)
        cout << "You decide to get the resources " << resource1 << " and " << resource2 << " from the stack" <<endl;
    else
        cout << "You decide to get two " << resource1 << "s from the stack" <<endl;

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //clean buffer
}

/*
 * get the players and the number of player who using card.
   the player take one resource from each player according his choice
 */
void Card::UsingmonopolyCard(vector<Player*>& p, size_t i){
    string card;
    cout << "Please enter one resource you want to get from other players: (brick, lumber, iron, wheat, wool) " << endl;
    cin >> card;
    cout << "You decide to get the resource " << card << endl;

    size_t res = (size_t)p[i]->getCardFromString(card);
    for (size_t j = 0; j < p.size(); j++)
    {
        if(j != i && p[j]->getResourcesPlayer()[res] > 0)
        {
            p[i]->setResources(res, p[i]->getResourcesPlayer()[res] + 1);
            p[j]->setResources(res, p[j]->getResourcesPlayer()[res] - 1);
        }
    }
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //clean the buffer
}


