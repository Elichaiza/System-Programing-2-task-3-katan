//elichaiza@gmail.com
//ID:318691821

#ifndef PROGRESSCARD_HPP
#define PROGRESSCARD_HPP

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <memory>

#include "DevelopmentCard.hpp"
#include "Player.hpp"

class Player;

using namespace std;

class Card : public DevelopmentCard
{
private:
    string TypeOfCard;
public:
   Card(string TypeOfCard);
    string getTypeCard();
    string getDevelopmentType() override;
    void regularCard(vector<Player *> &p, size_t i, Board &b) override;
    void UsingTwoRoadCard(Player* p, Board& b);
    void UsingplentyYearCard(Player* p);
    void UsingmonopolyCard(vector<Player*>&p, size_t i);

};

#endif