
//elichaiza@gmail.com
//ID:318691821
#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <cmath>
#include <algorithm>

#include "Vertex.hpp"
#include "Edge.hpp"
#include "Tile.hpp"
#include "Board.hpp"
#include "Catan.hpp"
#include "Player.hpp"

#include "DevelopmentCard.hpp"
#include "cavalier.hpp"
#include "point.hpp"
#include "Card.hpp"

using namespace std;

// constructor
Catan::Catan(Player *p1, Player *p2, Player *p3){
    this->players.push_back(p1);
    this->players.push_back(p2);
    this->players.push_back(p3);

    this->currentTurn = 0;
    this->mostCavalier = 0;
    cout<<"The players of the game is: "<<endl;
    p1->printPlayer();
    p2->printPlayer();
    p3->printPlayer();

    point *vp = new point();
    cavalier *a_cavalier = new cavalier();
    Card *card1 = new Card("building");
    Card *card2 = new Card("plenty");
    Card *card3 = new Card("monopoly");

    this->cards.push_back(vp);
    this->cards.push_back(a_cavalier);
    this->cards.push_back(card1);
    this->cards.push_back(card2);
    this->cards.push_back(card3);

}

vector<Player *> Catan::getPlayers(){
    return this->players;
}

vector<DevelopmentCard *> Catan::getCards(){
    return this->cards;
}

Board Catan::getBoard(){

    Board board;
    return board;
}



/**
 * choose random player to strat
 */
vector<Player *> Catan::chooseFirstPlayer() {
    int a=(rand()%3) +1;
    vector<Player *> ans = this->players;
    if(a==1) {
        cout << "The first player is: " <<players[0]->getName() << endl;
        ans[0]=players[0];
        int b=(rand() % 2) +1;
        if(b==1) {
            cout << "The second player is: " <<players[1]->getName() << endl;
            ans[1]=players[1];
            cout << "The third player is: " << players[2]->getName() << endl;
            ans[2]=players[2];
            return ans;
        }
        else {
            cout << "The second player is: " <<players[2]->getName() << endl;
            ans[1]=players[2];
            cout << "The third player is: " <<players[1]->getName() << endl;
            ans[2]=players[1];
            return ans;
        }
    }

    if(a==2) {
        cout << "The first player is: " <<players[1]->getName() << endl;
        ans[0]=players[1];
        int b=(rand() % 2) +1;
        if(b==1) {
            cout << "The second player is: " <<players[0]->getName() << endl;
            ans[1]=players[0];
            cout << "The third player is: " << players[2]->getName() << endl;
            ans[2]=players[2];
            return ans;
        }
        else {
            cout << "The second player is: " <<players[2]->getName() << endl;
            ans[1]=players[2];
            cout << "The thired player is: " <<players[0]->getName() << endl;
            ans[2]=players[0];
            return ans;
        }
    }
    if(a==3) {
        cout << "The first player is: " <<players[2]->getName() << endl;
        ans[0]=players[2];
        int b=(rand()%2) +1;
        if(b==1) {
            cout << "The second player is: " <<players[0]->getName() << endl;
            ans[1]=players[0];
            cout << "The third player is: " << players[1]->getName() << endl;
            ans[1]=players[1];
            return  ans;
        }
        else {
            cout << "The second player is: " <<players[1]->getName() << endl;
            ans[1]=players[1];
            cout << "The third player is: " << players[0]->getName() << endl;
            ans[0]=players[0];
            return ans;
        }
    }
    return ans;
}

void Catan::printPlayers(){
    for (size_t i = 0; i < this->players.size(); i++){
        this->players[i]->printPlayer();
    }
}

void Catan::endTurn(vector<Player *> p){
    // check if the acheive 10 points or more
    this->gameWinner(p[currentTurn]);

    currentTurn = (currentTurn + 1) % 3;
}

/**
 * The function get vector of players and rollNumber
 * The function finds who has settlemens or cities on junctions that limits with every tile with the rollNumber and add to player resources
 */
void Catan::addResources(vector<Player *> &players, int rollNumber){
    vector<Tile*> sameRollTiles = getBoard().findSameNumberOnTiles(rollNumber);

    for (size_t i = 0; i < sameRollTiles.size(); i++){ // go through all tiles with the current roll number
        Tile* t = sameRollTiles[i];
        for (size_t j = 0; j < players.size(); j++){ // go through all players
            Player *p = players[j];
            for (Vertex *v : p->getVillagesOfPlayer()){ // go through all settlemens of player
                if (t->findVertex(v) == true)
                    p->addResource(t->getLand()); // add resource if one of the settlements is on tile
            }

            for (Vertex *v : p->getCitiesOfPlayer()) // go through all cities of player
            {
                if (t->findVertex(v) == true)
                {
                    p->addResource(t->getLand()); // add double resource if one of the cities is on tile
                    p->addResource(t->getLand());
                }
            }
        }
    }
}

/**
 * The function halve the count of each resource for all the players
 */
void Catan::giveBackResources(vector<Player *> &players){
    cout << "The new resources are:" << endl;
    size_t n = players[0]->getResourcesPlayer().size();
    vector<int> newResources(n, 0);

    for (size_t i = 0; i < players.size(); i++){
        Player *p = players[i];
        int count = 0;

        // count all resources
        count += p->getResourcesPlayer()[brick];
        count += p->getResourcesPlayer()[Wood];
        count += p->getResourcesPlayer()[iron];
        count += p->getResourcesPlayer()[wheat];
        count += p->getResourcesPlayer()[wool];
        if (count > 7){
            count % 2 ? (++count) /= 2 : count /= 2; // halve count. if odd - round up

            // make new resources's vector according the new count
            int r = 0;
            while (count > 0)
            {
                count--;
                newResources[(size_t)r]++;
                r < 4 ? ++r : r = 0;
            }

            // change the count of each resource to new count
            for (size_t j = 0; j < n; j++)
            {
                p->setResources(j, newResources[j]);
                newResources[j] = 0;
            }
        }
        p->printResources();
    }
}

// Every time that player end his turn, catan check if he get 10 points before the member "currentTurn" pass over
void Catan::gameWinner(Player *p)
{
    if (p->getPointsOfPlayer() >= 10)
        cout << "The winner is: " << p->getName() << "!" << endl;
}

void Catan::clearCatan()
{
    for (size_t i = 0; i < cards.size(); i++)
        delete (cards[i]);
    cards.clear();
}