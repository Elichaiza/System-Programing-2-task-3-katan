#ifndef CATAN_HPP
#define CATAN_HPP

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
//elichaiza@gmail.com
//ID:318691821

#include "Vertex.hpp"
#include "Edge.hpp"
#include "Tile.hpp"
#include "Board.hpp"
#include "Player.hpp"

#include "DevelopmentCard.hpp"
#include "cavalier.hpp"
#include "point.hpp"
#include "Card.hpp"

class Player;
using namespace std;

class Catan{
private:
 vector<Player*> players;
 vector<DevelopmentCard*> cards;

public:
 size_t currentTurn;
 int mostCavalier;


 Catan(Player* p1, Player* p2, Player* p3);
 vector<Player*> getPlayers();
 vector<DevelopmentCard*> getCards();
 Board getBoard();

 vector<Player *> chooseFirstPlayer();
 void printPlayers();

 void addResources(vector<Player*>& p, int rollNumber);
 void giveBackResources(vector<Player*>& p);

 void endTurn(vector<Player*> p);
 void gameWinner(Player* p);

 void clearCatan();
};

#endif