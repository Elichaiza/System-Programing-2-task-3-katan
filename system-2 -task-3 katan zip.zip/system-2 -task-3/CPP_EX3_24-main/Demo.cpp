//elichaiza@gmail.com
//ID:318691821
/**
 * Demo file for Ex3.
 *
 */

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <cstdlib> // For rand() and srand()
#include <ctime>   //for time
#include "Vertex.hpp"
#include "Edge.hpp"
#include "Board.hpp"
#include "Player.hpp"
#include "Catan.hpp"
#include "cavalier.hpp"

using namespace std;

int main()
{
    Player p1("Amit",20,blue);
    Player p2("Yossi",26,red);
    Player p3("Dana",28,white);

    Catan catan(&p1,&p2,&p3);
    // Starting of the game. Every player places two vilege and two roads.
    catan.chooseFirstPlayer();
    // should print the name of the starting player

    Board board = catan.getBoard(); // get the board of the game.

    vector<Player *> players = catan.getPlayers(); //return the plyers of the game
//building two vileages for the first player
    players[0]->setResources(0,4);
    players[0]->setResources(1,4);
    players[0]->setResources(3,2);
    players[0]->setResources(4,2);

    players[0]->build_vileage(3,board);
    players[0]->buildRoad(3,4,board);

    players[0]->build_vileage(7,board);

    players[0]->buildRoad(7,8,board);

    //the seconed player try to builed in the same location of the firset player
    //we found that the place arent empty and print the problem
    try {
        players[1]->build_vileage(3,board);
    }
    catch (exception &e) {
        cout << e.what() << endl;
    }

    players[1]->setResources(0,4);
    players[1]->setResources(1,4);
    players[1]->setResources(3,2);
    players[1]->setResources(4,2);

    //building two vileages for the second player
    players[1]->build_vileage(22,board);
    players[1]->buildRoad(22,23,board);
    players[1]->build_vileage(25,board);
    players[1]->buildRoad(25,26,board);


    players[2]->setResources(0,4);
    players[2]->setResources(1,4);
    players[2]->setResources(3,2);
    players[2]->setResources(4,2);

    //building two vileages for the thired player
    players[2]->build_vileage(41,board);
    players[2]->buildRoad(41,50,board);

    players[2]->build_vileage(33,board);
    players[2]->buildRoad(33,34,board);


    //strting the game
    players[0]->rollDice(catan,players);
    catan.endTurn(players);
    //player one try to roll dice again
    //but the game dont get to him to do it because its not him turn;
    try {
        players[0]->rollDice(catan,players);
    }
    catch (exception &e) {
        cout << e.what() << endl;
    }

    players[1]->rollDice(catan,players);
    catan.endTurn(players);

    players[2]->rollDice(catan,players);
    catan.endTurn(players);

    players[0]->rollDice(catan,players);
    catan.endTurn(players);

    players[1]->rollDice(catan,players);
    catan.endTurn(players);


    players[2]->rollDice(catan,players);
    catan.endTurn(players);

    players[0]->rollDice(catan,players);
    //try to build a road
    players[0]->buildRoad(4,5,board);
    //try to build vileage
   // players[0]->build_vileage(5,board);
    catan.endTurn(players);

    players[1]->rollDice(catan,players);

    players[1]->buildRoad(26,27,board);
   players[1]->build_vileage(27,board);
    catan.endTurn(players);

    players[2]->rollDice(catan,players);
    players[2]->buildRoad(50,51,board);

    players[2]->build_vileage(15,board);
    catan.endTurn(players);

    players[0]->rollDice(catan,players);
    players[0]->trade(players[1],"Wood",1,"iron",1);
    players[0]->buildCity(3,board);
    players[0]->buyDevelopmentCard(catan,players,board);
    catan.endTurn(players);

    players[1]->rollDice(catan,players);
    players[1]->trade(players[2],"Wood",1,"brick",1);
    catan.endTurn(players);

    players[2]->rollDice(catan,players);
    players[2]->trade(players[1],"brick",1,"wheat",1);
    players[2]->buyDevelopmentCard(catan,players,board);
    catan.endTurn(players);

    cout << players[0]->getName() << " has: " << players[0]->getPointsOfPlayer() << " points" << endl;
    cout << players[1]->getName() << " has: " << players[1]->getPointsOfPlayer() << " points" << endl;
    cout << players[2]->getName() << " has: " << players[2]->getPointsOfPlayer() << " points" << endl;

    board.clearBoard(); //free all memory was allocate in board
    catan.clearCatan(); //free all memory was allocate in catan

    return 0;
}