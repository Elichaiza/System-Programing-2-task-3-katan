//elichaiza@gmail.com
//ID:318691821

#include "Edge.hpp"
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>
using namespace std;

Edge::Edge(Vertex *a, Vertex *b) {
    this->one=a;
    this->two=b;
    this->empty=true;
}
Edge::~Edge(){}

Vertex *Edge::getOneVertex() {
    return this->one;
}
Vertex *Edge::getTwoVertex() {
    return this->two;
}
int Edge::getNomOfVertexOne() {
    return this->one->GetIndex();
}
int Edge::getNumOfVertexTwo() {
    return this->two->GetIndex();
}

bool Edge::isEmpty() {
return this->empty;
}
int Edge::getRoadColor() {
    return this->roadColor;
}
void Edge::setRoadColor(int a) {
    if(a!=blue&& a!=red && a!=white) {
        __throw_invalid_argument("the color is not exist you need to chooce between: blue , red or whitw only!");
        exit(1);
    }
    this->roadColor=a;
}
void Edge::BuildARoad() {
    if(this->empty==true) {
        this->empty=false;
    }
   else{cout<<"the road is alredy taken" ;}

}
bool Edge::Equal(int nodeOne, int noedTwo) {
    if(this->one->GetIndex()==nodeOne &&this->two->GetIndex()==noedTwo || this->one->GetIndex()==noedTwo && this->two->GetIndex()==nodeOne) {
        return true;
    }
    return false;

}







