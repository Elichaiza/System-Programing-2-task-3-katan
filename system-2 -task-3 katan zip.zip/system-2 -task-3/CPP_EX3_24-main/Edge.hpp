//elichaiza@gmail.com
//ID:318691821

#ifndef EDGE_H
#define EDGE_H

#include <iostream>
#include "Vertex.hpp"
#include <stdexcept>
#include <utility>
#include <vector>
using namespace std;

#define blue 1
#define red 2
#define white 3


class Edge {
private:
    Vertex* one;
    Vertex* two;
    int roadColor=0;
    bool empty=true;

public:
    Edge(Vertex* a, Vertex* b);
    ~Edge();
    int getNomOfVertexOne();
    int getNumOfVertexTwo();
    Vertex* getOneVertex();
    Vertex* getTwoVertex();
    void setRoadColor(int a);
    int getRoadColor();
    bool isEmpty();
    void BuildARoad();
    bool Equal(int nodeOne, int noedTwo);

};



#endif //EDGE_H
