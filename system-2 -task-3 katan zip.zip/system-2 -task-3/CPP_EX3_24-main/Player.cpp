//elichaiza@gmail.com
//ID:318691821

#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>
#include <set>
#include <cstdlib>
#include <ctime>
#include <limits>
#include "Player.hpp"
#include "Vertex.hpp"
#include "Edge.hpp"
#include "Tile.hpp"
#include "Board.hpp"
#include "Catan.hpp"

using namespace std;

Player::Player( string name, int age, int color)  : name(name), age(age), color_game(color), cards(5, 0) { }

string Player::getName() {
    return this->name;
}
int Player::getAge() {
    return this->age;
}
// print the data on the player
void Player::printPlayer(){
    cout << "Name: " << this->getName() << endl
         << "Age: " << this->getAge() << endl;
    if (color_game == 1)
        cout << "Color: Blue" << endl;
    if (color_game == 2)
        cout << "Color: Red" << endl;
    if (color_game == 3)
        cout << "Color: White" << endl;
    cout << "Points: " << this->getPointsOfPlayer() << endl;
    cout << endl;
}
//get how much point have to the player
int Player::getPointsOfPlayer(){
    return this->points;
}
//add points to the player
void Player::setPointsToPlayer(int addPoints){
    this->points += addPoints;
}
//return the color of the player in the game
int Player::getColorOfPlayer(){
    return this->color_game;
}
//return the cards of the player
vector<int> Player::getResourcesPlayer(){
    return this->cards;
}
//casting the string card that the player get to int
int Player::getCardFromString(string card){
    if (card == "brick")
        return brick;
    if (card == "Wood")
        return Wood;
    if (card == "iron")
        return iron;
    if (card == "wheat")
        return wheat;
    if (card == "wool")
        return wool;
    return -1;
}

vector<Edge *> Player::getRoadsOfPlayer(){
    return this->roads;
}

vector<Vertex *> Player::getVillagesOfPlayer(){
    return this->villages;
}

vector<Vertex *> Player::getCitiesOfPlayer()
{
    return this->cities;
}

//get way and check if the player can building vileage on the nodes of the edge
    bool Player::can_build_a_vileage(Edge *e, Board &b) {

   bool ans = can_builed_on_this_node(e->getTwoVertex(),b);
    if (ans == false) {
        throw std::invalid_argument("Vertex is null");
    }
    //if (can_builed_on_this_node(e->getOneVertex(), b)) {
        // // if the wey arent exsist on the board
        // if (e == NULL)
        //     __throw_invalid_argument("Failed indexes: No exist edge with these indexes in the board");

        // if the lane does not empty so throw error
        if (e->isEmpty() == false)
            __throw_invalid_argument("Building failed! The lane isn't empty");

        // First, check if there are vileage or city-with this color of the player-on any vertex of edge
        if (e->getOneVertex()->GetColor() == this->color_game || e->getOneVertex()->GetColor()  == this->color_game)
            return true;

        // Second, check if there are roads-with the same color of the player-that intersection with any vertex of edge
        vector<Edge *> waysNeighborhood1 = b.edgesIntersection(e->getOneVertex());
        for (size_t i = 0; i < waysNeighborhood1.size(); i++)
        {
            if (waysNeighborhood1[i] != e && waysNeighborhood1[i]->getRoadColor() == this->color_game)
                return true;
        }
        vector<Edge *> waysNeighborhood2 = b.edgesIntersection(e->getTwoVertex());
        for (size_t i = 0; i < waysNeighborhood2.size(); i++)
        {
            if (waysNeighborhood2[i] != e && waysNeighborhood2[i]->getRoadColor() == this->color_game)
                return true;
        }
        return false;
    }



/**
 the player need to give a two nodes and if the way is empty
 we put the way in this location.
 */
bool Player::buldingRoad(int node1, int node2, Board &b){
    Edge *rode = b.find_way(node1, node2);
    //check if the road are empty

    if (!can_build_a_vileage(rode, b)){
        __throw_invalid_argument("Building failed! You don't have any road, settlement or city that adjacent to lane");
    }

    rode->BuildARoad();               // build on that way
    rode->setRoadColor(this->color_game); // paint the way on player's color
    roads.push_back(rode);       // add the edge to player's vector of roads
    cout << this->getName() << " build new road on lane " << "(" << node1 << "," << node2 << ")" << endl
         << endl;
    return true;
}

// get a vertex and return true if it's possible to build on that vertex
bool Player::can_builed_on_this_node(Vertex *v, Board &b){
    // if vertex not found

    if (v == NULL) {
        __throw_invalid_argument("Failed index: No exist vertex with this index in the board");
    }
    // if junction is not empty
    if (!v->IsEmpty()) {
        __throw_invalid_argument("Building failed: The lane is not empty");
    }

    // Distance Rule - check if does not exist settlements or cities that adjacent to v
    vector<Edge *> lanesNeighborhood = b.edgesIntersection(v);
    for (size_t i = 0; i < lanesNeighborhood.size(); i++){
        if ( lanesNeighborhood[i]->getTwoVertex()->IsEmpty() == false)
            __throw_invalid_argument("Building failed according 'Distance Rule'");
    }

    // If this is build of the begin of game
    if (villages.size() + cities.size() < 2)
        return true;

    // Finally, check if there are exist roads that leads to v
    for (size_t i = 0; i < lanesNeighborhood.size(); i++)
    {
        if (lanesNeighborhood[i]->getRoadColor() == this->color_game)
            return true;
    }
    return true;
}

/**
 * The function get index of node and the board.
 * If the node exists in board and is empty - build vileage on that node
 */
void Player::build_vileage(int node, Board &b){
    Vertex *v = b.find_node(node); // v has the address of vertex that his index is junction in board

    if (!can_builed_on_this_node(v, b))
        __throw_invalid_argument("Building failed! You don't have any road that leads to node");

    v->buildASettlement();               // build on that junction
    v->SetColor(this->color_game); // paint the lane to player's color
    points++;                 // take more point
    villages.push_back(v); // add the vertex to player's vector of settlements
    cout << this->getName() << " build new vileage on node " << v->GetIndex() << endl;
    cout << endl;

    // get cards after place two settlements before the game start
    if (villages.size() == 2)
        this->getBeginnersResource(b);
}



/**
 * Each player get cards from lands that his settlememts limits them
 */
void Player::getBeginnersResource(Board &b){
    for (size_t i = 0; i < this->villages.size(); i++)
    {
        vector<Tile*> intersection = b.tilesIntersection(villages[i]);
        for (size_t i = 0; i < intersection.size(); i++)
        {
            addResource(intersection[i]->getLand());
        }
    }
    printResources();
}

void Player::setResources(int type, int count){
    for(size_t i=0;i<count;i++) {
        this->cards[(size_t)type]++;
    }
    cout<<"the resource adding" <<endl;
}

/**
 * The function get land and adding this land resource to the player
 */
void Player::addResource(string land){
    int ans=-1;
    if( land == "brick"){ans=0;}
    if( land == "Wood"){ans=1;}
    if( land == "iron"){ans=2;}
    if( land == "wheat"){ans=3;}
    if( land == "wool"){ans=4;}
    switch (ans) {

    case  0:
        cards[brick]++;
        cout<<"the resource adding" <<endl;
        return;

    case 1:
        cards[Wood]++;
        cout<<"the resource adding" <<endl;
        return;

    case 2:
        cards[iron]++;
        cout<<"the resource adding" <<endl;
        return;

    case 3:
        cards[wheat]++;
        cout<<"the resource adding" <<endl;
        return;

    case 4:

        cards[wool]++;
        cout<<"the resource adding" <<endl;
        return;
    default:return;
    }
    return;
}

void Player::printResources() {
    if (cards.size()!=0){
        cout << this->getName() << " has this resourcrs:";
        cout << " Brick: " << cards[0];
        cout << ", Wood: " << cards[1];
        cout << ", Iron: " << cards[2];
        cout << ", Wheat: " << cards[3];
        cout << ", Wool: " << cards[4];
        cout << endl;
    }
}

// return number in between 1 to 6
int Player::rollCube(){
    return 1 + (rand() % 6);
}

/**
 * random number in range(2,12)
 * if it's 7 - call giveBackcards
 * else - call sharecards
 */
void Player::rollDice(Catan &catan, vector<Player *> &p){
    if (this->getName() != catan.getPlayers()[catan.currentTurn]->getName())
        __throw_invalid_argument("Roll failed. It's not your turn!");

    int cube1 = rollCube();
    int cube2 = rollCube();
    int result = cube1 + cube2;
    cout << "The result of the dice is: " << result << endl
         << endl;

    if (result == 7)
    {
        cout << "All players need to divide them cards" << endl;
        catan.giveBackResources(p);
    }
    else
        catan.addResources(p, result);
}

// get two indexes that represent edge and build new road on it(if possible)
void Player::buildRoad(int node1, int node2, Board &b) {
    if (cards[brick] < 1 || cards[Wood] < 1) {
        cout << "You have not enough resources to build new road" << endl;
        return;
    }
   if(this->cards[brick] >= 1 && this->cards[Wood] >= 1) {
        if(buldingRoad(node1, node2, b)){
            this->cards[brick]--;
            this->cards[Wood]--;
        }

    }
}


// get index represens nodes and build new vileage on it(if possible)
void Player::buildvileage(int node, Board &b){
    if (cards[brick] < 1 || cards[Wood] < 1 || cards[wheat] < 1 || cards[wool] < 1){
        cout << "You have not enough resources to build new vileage" << endl;
        return;
    }
    build_vileage(node, b);
    cards[brick]--;
    cards[Wood]--;
    cards[wheat]--;
    cards[wool]--;
    cout<<"your vileage are built"<<endl;
}

// get index represens node of vileage and build new city on it(if possible)
void Player::buildCity(int node, Board &b){
    if (cards[iron] < 3 || cards[wheat] < 2){
        cout << "You have not enough resources to build new city" << endl;
        return;
    }
    Vertex *v = b.find_node(node);
    if (v->GetColor() != this->color_game)
        __throw_invalid_argument("Build failed! You cann't build city here because you haven't vileage on this node");
    points += 1;         // take more 1 points
    cities.push_back(v); // add the vertex to player's vector of cities
    // remove the vertex from player's vector of settlements
    size_t i = 0;

    if (this->villages.size() == 1){
        auto it = this->villages.begin();
        this->villages.erase(it);
    }
    else{
        for (auto it = this->villages.begin(); it != this->villages.end(); ++it){
            if ((*it) == v)
                it = this->villages.erase(it);
        }
    }
    cards[iron] -= 3;
    cards[wheat] -= 2;

    cout << this->getName() << " build new city on node " << v->GetIndex() << endl;
    cout << endl;
}
/**
 * The function get player, resource to trade, resource to take and their count.
 * The functin ask the player if he agree to trade (if possible)
 */
void Player::trade(Player *p, string yourResource, int countReceive, string myResource, int countGive){
    size_t wantedResource = (size_t)p->getCardFromString(yourResource);
    size_t unwantedResource = (size_t)this->getCardFromString(myResource);
   if(this->cards.size()==0||p->cards.size()==0) {
       cout << "Deal Failed! You don't have cards enough" << endl;
       cout << endl;
       return;
   }
    if (this->cards[unwantedResource] < countGive || p->cards[wantedResource] < countReceive) {
        cout << "Deal Failed! You don't have cards enough" << endl;
        cout << endl;
        return;
    }


    cout << p->getName() << ", do you want to trade " << countReceive << " " << yourResource << " instead of " << countGive << " " << myResource << " with " << this->getName() << "? [Y/n] ";
    char answer = getchar(); // get answer (Yes/No) from the player

    if (answer == 'Y')
    {
        this->cards[wantedResource] += countReceive;
        this->cards[unwantedResource] -= countGive;
        p->setResources(wantedResource, p->getResourcesPlayer()[wantedResource] - countReceive);
        p->setResources(unwantedResource, p->getResourcesPlayer()[unwantedResource] + countGive);

        cout << endl
             << this->getName() << " and " << p->getName() << " have a deal!" << endl;
        cout << "The new cards are:" << endl;
        this->printResources();
        p->printResources();
    }

    else
        cout << p->getName() << " didn't agree to the deal" << endl;

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // clean the buffer for the next trade
}

int Player::getKnights() { return this->cavalier; }
void Player::addKnights() { this->cavalier++; }
bool Player::hasLargestArmy() { return largest_cavalieres;}
void Player::lossLargestArmy() { this->largest_cavalieres = false; }

/**
 * Every time that player get development card from type "knights" he called to this function.
 * The function check if the player has 3 or more knights more over each other player.
 * If he has, the function uodate the boolean varriable "largestArmy" for all players
 * and the generall boolean variable "largestArmy"
 */
void Player::reachLargestArmy(Catan &catan, vector<Player *> &p)
{
    if (this->cavalier >= 3 && this->cavalier > catan.mostCavalier)
    {
        cout << this->getName() << " acheive the largest army" << endl;
        catan.mostCavalier = this->cavalier;
        for (size_t i = 0; i < p.size(); i++)
        {
            if (p[i]->getName() == this->getName())
                this->largest_cavalieres = true;
            else
                p[i]->lossLargestArmy();
        }
    }
}

/**
 * The function random number between 1 to 5
 * The number represents the index of the decelopment cards which in catan's vector of cards 
 * If the number is index of developmend card "knights" - check if the player get the "largest army"
 * If the player has not cards enough - return
 */
void Player::buyDevelopmentCard(Catan &catan, vector<Player *> &p, Board &b)
{
    if (cards[iron] < 1 || cards[wheat] < 1 || cards[wool] < 1)
    {
        cout << "You have not enough cards to buy a development card" << endl;
        return;
    }

    int randomCard = (rand() % 5); // random number(1,5) that represents index in catan's vector of develpment cards
    catan.getCards()[(size_t)randomCard]->regularCard(p, catan.currentTurn, b);

    if (randomCard == 1) // if the card is a knight
        this->reachLargestArmy(catan, p);
}


void Player::cleanPlayer()
{
    roads.clear();
    villages.clear();
    cities.clear();
}