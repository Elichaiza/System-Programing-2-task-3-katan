//elichaiza@gmail.com
//ID:318691821

#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <cstdlib>
#include <ctime>
#include <limits>
#include "Vertex.hpp"
#include "Edge.hpp"
#include "Tile.hpp"
#include "Board.hpp"

class Catan;
using namespace std;

#define brick 0
#define Wood 1
#define iron 2
#define wheat 3
#define wool 4


class Player
{
private:
    string name;
    int age;
    int points = 0;
    int color_game;
    vector<int> cards;

    vector<Edge*> roads;
    vector<Vertex*>  villages;
    vector<Vertex*> cities;

    int cavalier = 0;
    bool largest_cavalieres = false;

public:

    Player(string name, int age, int color);
    string getName();
    int getAge();
    void printPlayer();
    int getPointsOfPlayer();   //return how much point have to the player
    void setPointsToPlayer(int increasePoints);   //give to the player points
    int getColorOfPlayer();  //return the collor of the player
    vector<int> getResourcesPlayer();                           // return player's resources
    int getCardFromString(string r);                  // get Card as string and return it as int
    void setResources(int typeResource, int newCount);    // get resource and change the count of it
    void addResource(string land);                          //get land and add the product to player's resources
    void getBeginnersResource(Board &b);                  //add resources according the places of settlements
    void printResources();

    vector<Edge*> getRoadsOfPlayer();            //return player's roads
    vector<Vertex*> getVillagesOfPlayer();    //return player's settlements
    vector<Vertex*> getCitiesOfPlayer();         //return player's cities
    bool can_build_a_vileage(Edge* e, Board& b);
    bool buldingRoad(int node1, int node2, Board& b);
    bool can_builed_on_this_node(Vertex* v, Board& b);
    void build_vileage(int node, Board& b);


    int rollCube();
    void rollDice(Catan& catan, vector<Player*>& p);

    void buildRoad(int junction1, int junction2, Board& b);
    void buildvileage(int node, Board& b);
    void buildCity(int junction, Board& b);

    void trade(Player* p, string wantedResource, int countReceive, string unwantedResource, int countGive);

    int getKnights();
    void addKnights();
    bool hasLargestArmy();
    void reachLargestArmy(Catan& catan, vector<Player*>& p);
    void lossLargestArmy();

    void buyDevelopmentCard(Catan& catan, vector<Player*>& p, Board& b);

    void cleanPlayer();

};

#endif
