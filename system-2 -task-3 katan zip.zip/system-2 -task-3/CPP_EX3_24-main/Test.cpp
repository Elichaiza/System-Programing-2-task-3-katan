//elichaiza@gmail.com
//ID:318691821

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <cstdlib> // For rand() and srand()
#include <ctime>   //for time
#include <limits>
#include "doctest.h"
#include "Vertex.hpp"
#include "Edge.hpp"
#include "Tile.hpp"
#include "Board.hpp"
#include "Person.hpp"
#include "Player.hpp"
#include "Catan.hpp"
#include "DevelopmentCard.hpp"
#include "cavalier.hpp"
#include "point.hpp"
#include "Card.hpp"
//#include "../../../../../Program Files/JetBrains/CLion 2024.1.1/bin/mingw/x86_64-w64-mingw32/include/complex.h"

using namespace std;

TEST_CASE("Vertexes") {

    Vertex a(9);
    a.buildASettlement();
    CHECK_FALSE(a.IsEmpty());
    CHECK(a.GetIndex()==9);

    Vertex b(13);
    CHECK(b.IsEmpty());
    CHECK_FALSE(b.GetIndex()==11);
    b.buildASettlement();
    CHECK_FALSE(b.IsEmpty());
}
TEST_CASE("Edges") {
    Vertex a(5);
    Vertex b(5);
    Vertex c(6);
    Vertex d(7);
    Edge one(&a,&c);
    Edge two(&b,&d);
    CHECK_FALSE(one.isEmpty());
    CHECK(one.getOneVertex()->GetIndex()==5);
    CHECK(one.getTwoVertex()->GetIndex()==6);
    CHECK(one.Equal(5,6));
   cout<<"the test of Edges successfully passed"<<endl;

}
TEST_CASE("Tiles&Borad") {
    Board a;
    CHECK(a.find_node(13));
    REQUIRE_THROWS_AS(a.find_node(156),invalid_argument);
    CHECK(a.find_way(21,22));
    Tile* t1 = a.getBoard()[0];
    Tile* t2 = a.getBoard()[1];
    CHECK(t1->getVertexes()[2] == t2->getVertexes()[0]); // same vertex in different tiles

    int roll = t1->getCircleNumber();
    vector<Tile*> tiles = a.findSameNumberOnTiles(roll);
    for (size_t i = 0; i < tiles.size(); i++){
        CHECK(tiles[i]->getCircleNumber() == roll);
    }
    tiles.clear();
}
TEST_CASE("Dices&EndTurn") {
    Player a("avi",19,blue);
    Player b("yosi",24,red);
    Player c("ron",22,white);

    Catan catan(&a,&b,&c);
    vector<Player*>players =catan.chooseFirstPlayer();
    players[0]->rollDice(catan,players);
    catan.endTurn(players);
    CHECK_THROWS(players[0]->rollDice(catan,players));
}

    TEST_CASE("catan") {
        Player a("avi",19,blue);
        Player b("yosi",24,red);
        Player c("ron",22,white);

        Catan catan(&a,&b,&c);
        vector<Player*>players =catan.chooseFirstPlayer();
       CHECK_FALSE(catan.currentTurn==1);
        CHECK(catan.currentTurn==0);
        players[0]->rollDice(catan,players);
        catan.endTurn(players);
        CHECK(catan.currentTurn==1);
    catan.clearCatan();
}
    TEST_CASE("build") {
    Player a("avi",19,blue);
    Player b("yosi",24,red);
    Player c("ron",22,white);
    Board board;
    Catan catan(&a,&b,&c);
    vector<Player*>players =catan.chooseFirstPlayer();
    players[1]->buildRoad(6,7,board);//try to buy a road but he dident have the  resources.
    CHECK_FALSE(players[1]->getRoadsOfPlayer().size()==3);
    players[0]->build_vileage(4,board);
    CHECK_FALSE(players[0]->getVillagesOfPlayer().size()==3);
    players[0]->rollDice(catan,players);
    players[0]->setResources(1,2);
    players[0]->setResources(0,2);
    players[0]->buildRoad(5,6,board);
    players[0]->buildRoad(6,7,board);
    catan.endTurn(players);
    CHECK(players[0]->getRoadsOfPlayer().size()==4);

    players[1]->rollDice(catan,players);
    players[1]->setResources(2,3);
    players[1]->setResources(3,2);
    int aa=players[1]->getVillagesOfPlayer().front()->GetIndex();
    players[1]->buildCity(aa,board);
    CHECK(players[1]->getCitiesOfPlayer().size()==1);
    CHECK(players[1]->getPointsOfPlayer()==3);

}

TEST_CASE("cards") {
    Player a("avi",19,blue);
    Player b("yosi",24,red);
    Player c("ron",22,white);
    Board board;
    Catan catan(&a,&b,&c);
    vector<Player*>players =catan.chooseFirstPlayer();
    for (size_t i =0;i<3;i++) {
        CHECK(players[i]->getResourcesPlayer().size()==0);
    }
    players[1]->setResources(2,1);
    CHECK(players[1]->getResourcesPlayer().size()==1);
    players[2]->setResources(4,10);
    CHECK_FALSE(players[2]->getResourcesPlayer().size()==5);
    CHECK(players[2]->getResourcesPlayer().size()==10);
    players[1]->trade(players[2],"wool",1,"iron",4);
    CHECK(players[1]->getResourcesPlayer().size()==1);
    CHECK(players[2]->getResourcesPlayer().size()==7);

}

TEST_CASE("trade_cards") {
    Player a("avi",19,blue);
    Player b("yosi",24,red);
    Player c("ron",22,white);
    Board board;
    Catan catan(&a,&b,&c);
    vector<Player*>players =catan.chooseFirstPlayer();
    players[0]->setResources(0,5);
    players[1]->setResources(1,5);
    players[2]->setResources(2,5);
    players[0]->trade(players[1],"Wood",2,"brick",1);
    CHECK(players[0]->getResourcesPlayer().size()==6);
    players[1]->trade(players[2],"iron",2,"Wood",1);
    CHECK(players[1]->getResourcesPlayer().size()==5);
}




