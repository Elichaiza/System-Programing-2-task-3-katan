//elichaiza@gmail.com
//ID:318691821

#include "Edge.hpp"
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>
#include "Tile.hpp"

using namespace std;

Tile::Tile(vector<Vertex*> vertexes,vector<Edge*> edges,int circleNumber,string land) {
    this->land=land;
    this->CircleNumber=circleNumber;
    this->vertexes=vertexes;
    this->edges=edges;

}
Tile::~Tile(){}
vector<Edge *> Tile::getEdges() {
    return this->edges;
}

string Tile::getLand() {
    return this->land;
}

vector<Vertex *> Tile::getVertexes() {
return this->vertexes;
}
bool Tile::findVertex(Vertex *v) {
    for(size_t i=0;i<6;i++) {
        if(vertexes[i]=v) {
            return true;
        }
    }
    return false;
}

int Tile::getCircleNumber() {
    return this->CircleNumber;

}

void Tile::setCircleNumber(int number) {
this->CircleNumber=number;
}











