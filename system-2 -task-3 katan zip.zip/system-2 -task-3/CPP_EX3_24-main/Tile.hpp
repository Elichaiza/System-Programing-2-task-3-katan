//elichaiza@gmail.com
//ID:318691821

#ifndef TILE_H
#define TILE_H


#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>

using namespace std;

class Tile {
private:
    string land;
    vector<Vertex*> vertexes;
    vector<Edge*> edges;
    int CircleNumber=0;

public:
    Tile(vector<Vertex*> vertexes,vector<Edge*> edges,int circleNumber,string land );
    ~Tile();
    vector<Vertex*> getVertexes();
    vector<Edge*> getEdges();
    void setCircleNumber(int number);
    int getCircleNumber();
    string getLand();
    bool findVertex(Vertex* v);
};



#endif //TILE_H
