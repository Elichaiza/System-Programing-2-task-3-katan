//elichaiza@gmail.com
//ID:318691821

#include "Vertex.hpp"
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>
using namespace std;

Vertex::Vertex(int index) {
    if (index<0||index>53) {
        __throw_invalid_argument("the index need to be between 1-53");
        exit(0);
    }
    this->index=index;
    this->empty=true;

}

Vertex::~Vertex()= default;

void Vertex::SetColor(int a) {
    if(&a!=nullptr){
        if(a!=blue&& a!=red && a!=white) {
            __throw_invalid_argument("the color is not exist you need to chooce between blue or red or whitw only!");
            return;
        }
        if(this!=NULL) {
            this->color=a;
        }
    }
}

int Vertex::GetColor() const {
    return this->color;
}
int Vertex::GetIndex() const  {
    if (this!=NULL){
     if (this->index > 53 ||this->index<0) {
         throw std::invalid_argument("Vertex is null");
     }
    return this->index;
} return -1;
}
bool Vertex::IsEmpty() const {
    return this->empty;
}
void Vertex::buildASettlement() {
    if(this!=NULL) {
        this->empty=false;
    }
}






