//elichaiza@gmail.com
//ID:318691821

#ifndef VERTEX_H
#define VERTEX_H

#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>
using namespace std;

#define blue 1
#define red 2
#define white 3

class Vertex {
private:
    int color=0;
    int index;
    bool empty=true;
public:
    Vertex(int index);
    ~Vertex();

    int GetIndex() const ;
    void SetColor(int a);
    int GetColor() const;
    bool IsEmpty() const;
    void buildASettlement();





};



#endif //VERTEX_H
