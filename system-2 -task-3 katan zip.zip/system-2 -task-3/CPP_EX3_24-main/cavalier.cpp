//elichaiza@gmail.com
//ID:318691821

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include "DevelopmentCard.hpp"
#include "cavalier.hpp"
#include "Player.hpp"

using namespace std;

cavalier::cavalier()= default;

string cavalier::getDevelopmentType(){
    return "cavalier";
}
/**
 * get the players, the number of player who using card and the board.
   add to player who use the card cavalier.
 */
void cavalier::regularCard(vector<Player*>& p, size_t i, Board& b){
    cout << p[i]->getName() << " reach the development card " <<  this->getDevelopmentType()  << endl;
    p[i]->addKnights();
}