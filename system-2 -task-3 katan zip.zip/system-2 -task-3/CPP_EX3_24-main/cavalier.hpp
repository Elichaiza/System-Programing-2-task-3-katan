//elichaiza@gmail.com
//ID:318691821

#ifndef CAVALIER_H
#define CAVALIER_H
#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <memory>
#include "DevelopmentCard.hpp"
#include "Player.hpp"

class Player;

using namespace std;

class cavalier : public DevelopmentCard
{
public:
    cavalier();
    string getDevelopmentType() override;
    void regularCard(vector<Player *>& p, size_t i, Board& b) override;
};

#endif //CAVALIER_H
