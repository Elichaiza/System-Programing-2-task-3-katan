
//elichaiza@gmail.com
//ID:318691821
#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>


#include "DevelopmentCard.hpp"
#include "point.hpp"
#include "Player.hpp"

using namespace std;

point::point(){}

string point::getDevelopmentType()
{
    return "victory point";
}

/*
 * get the players, the number of player who using card and the board.
    add to player who use the card point.
*/
void point::regularCard(vector<Player*>& p, size_t i, Board& b)
{
    cout << p[i]->getName() << " reach the development card " <<  this->getDevelopmentType()  << endl;  
    p[i]->setPointsToPlayer(1);
}